# LXME Financial Services — Reference File
*Role: Associate Product Manager*
*Period: May 2024 – Dec 2024*
*Version: 1.0 | Updated: May 2026*

---

## Context
LXME is India's financial independence platform for women. Om joined as APM and owned
onboarding conversion, app stability, Prepaid Instrument (PPI) launch, and the Lxme Lite
market expansion strategy for Tier 2-3 cities.

**Framing for interviews:** Use LXME for:
- Onboarding conversion and funnel optimization
- App stability and technical quality
- New product launch (PPI / digital wallets)
- Market expansion to underserved segments (Tier 2-3)
- Vendor partnership acceleration
- Reporting infrastructure and data frameworks

**Compress or omit for B2B/infra roles:** Compress to 2-3 bullets.
Use fully for B2C, consumer fintech, or growth-focused roles.

---

## STAR Nodes

### OM-LXME-001: Onboarding Conversion Optimization ★ PRIMARY ANCHOR
**Situation:** Late-stage onboarding abandonment was at 81%, severely limiting
conversion from sign-up to active user.
**Task:** Redesign the onboarding experience to eliminate friction and improve conversion.
**Actions:**
- Conducted friction analysis across the full onboarding flow — identified critical drop-off points
- Redesigned specific steps where users were abandoning (likely KYC, document upload, investment setup)
- Validated changes against user behavior data to confirm friction reduction
- Iterated based on post-launch conversion signals
**Results:**
- Late-stage abandonment: 81% → 32% (60% relative improvement)
- Directly improved conversion from registered user to active investor
**Decision authority:** Final call and execution

### OM-LXME-002: App Stability — Crash Rate Reduction ★
**Situation:** App crash rate was at 7%, significantly impacting user retention and
Play Store discoverability ranking.
**Task:** Drive app stability and reduce crash rate to improve organic retention.
**Actions:**
- Identified top crash-causing issues by analyzing Firebase/crash reporting data
- Prioritized engineering fixes based on crash frequency and user impact
- Collaborated with engineering team on systematic resolution
- Monitored Play Store performance and crash metrics post-fix
**Results:**
- Crash rate: 7% → 1.72% (75% relative reduction)
- Improved organic user retention and Play Store discoverability
**Decision authority:** Strong influence and execution

### OM-LXME-003: PPI Launch — Full-KYC Digital Wallets ★
**Situation:** LXME needed to launch Prepaid Instruments (PPI) to expand its financial
product suite and streamline investment journeys.
**Task:** Drive the end-to-end product lifecycle for PPI launch.
**Actions:**
- Led full-KYC digital wallet product definition and launch
- Integrated MF Central for centralized investment tracking
- Defined and implemented automated reporting frameworks for PPI metrics
- Coordinated across compliance, engineering, and business teams for launch
**Results:**
- PPI launched for 50,000+ active users
- Centralized investment tracking via MF Central integration
**Decision authority:** Strong influence and execution

### OM-LXME-004: Vendor Partnership Acceleration
**Situation:** Vendor integrations (KRA providers, FD platforms) were taking longer
than necessary, delaying feature delivery.
**Task:** Accelerate time-to-market through vendor partnership orchestration.
**Actions:**
- Orchestrated partnerships with KRA providers and FD platforms
- Managed integration timelines and vendor alignment
- Reduced coordination overhead between internal engineering and external vendors
**Results:**
- Time-to-market accelerated by 30%
- Significantly expanded app's product capabilities
**Decision authority:** Strong influence and execution

### OM-LXME-005: Lxme Lite — Tier 2-3 Market Expansion ★
**Situation:** Connectivity barriers in Tier 2-3 cities were preventing LXME from
reaching a large underserved segment of women investors.
**Task:** Solve the connectivity problem and build a distribution model for non-metro users.
**Actions:**
- Conceptualized Lxme Lite as a lightweight product for low-connectivity environments
- Designed hybrid digital-physical distribution model using banking correspondents
- Built channel strategy bridging digital onboarding with physical touchpoints
**Results:**
- 40% growth in user base
- New distribution channel established via banking correspondents
**Decision authority:** Final call (conceptualization and strategy)

### OM-LXME-006: Analytics & Reporting Infrastructure
**Situation:** Product and business teams lacked real-time visibility into PPI
performance, investment activity, and in-app engagement.
**Task:** Build automated reporting frameworks for data-informed decision making.
**Actions:**
- Architected automated reporting for PPI, daily investments, and in-app challenges
- Built real-time dashboards for engagement tracking
- Designed reporting to support data-driven iteration on engagement strategies
**Results:**
- Real-time dashboards operational for multiple product lines
- Data-informed engagement strategy enabled
**Decision authority:** Final call

---

## Key Numbers
- 81% → 32% onboarding abandonment (60% improvement)
- 7% → 1.72% crash rate (75% reduction)
- 40% user base growth via Lxme Lite
- 30% time-to-market acceleration via vendor partnerships
- PPI launched for 50,000+ active users

## Tools
Figma, Miro, Jira, MoEngage, Appsflyer, Firebase, Google Analytics, SQL, Python, Metabase

*Version: 1.0 | Updated: May 2026*
