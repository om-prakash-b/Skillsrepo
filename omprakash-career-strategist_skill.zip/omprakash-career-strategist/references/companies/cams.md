# CAMS FinServ Account Aggregator — Reference File
*Role: Product Management Trainee*
*Period: Apr 2023 – May 2024*
*Version: 1.0 | Updated: May 2026*

---

## Context
CAMS FinServ operates an Account Aggregator (AA) platform under RBI's AA framework.
Om joined as PM Trainee — his first product role — and owned merchant onboarding,
ecosystem partnerships (Sahamati), enterprise FIU expansion, LAS AA framework,
ReBIT compliance, and SQL analytics infrastructure.

**Framing for interviews:** Use CAMS for:
- AA/Open Finance ecosystem depth (rare and valuable signal)
- Merchant and FIU onboarding journeys
- ReBIT compliance and regulatory product work
- SQL analytics and CSAT-driven client servicing
- Loan Against Securities (LAS) credit product using AA
- Sahamati hackathon win as proof of initiative

**This is Om's foundational role — treat with care.** Frame as building blocks,
not seniority. The AA depth and hackathon win are genuinely differentiated.

---

## STAR Nodes

### OM-CAMS-001: Merchant Onboarding Revamp ★
**Situation:** Merchant onboarding journey had high drop-off and operational inefficiency,
limiting platform adoption.
**Task:** Revamp the journey based on data-backed friction analysis.
**Actions:**
- Conducted friction analysis across the merchant onboarding flow
- Identified key drop-off points using data and UX review
- Implemented UX refinements and process changes based on findings
- Validated improvements with platform performance metrics
**Results:**
- 78% platform efficiency achieved
- 32% reduction in user drop-off
**Decision authority:** Strong influence and execution

### OM-CAMS-002: Sahamati Ecosystem Partnership ★
**Situation:** CAMS FinServ needed to deepen its position within the Open Finance
ecosystem and improve system reliability through industry coordination.
**Task:** Represent the platform in the Sahamati (AA governing body) ecosystem.
**Actions:**
- Partnered with Sahamati to influence the Account Aggregator ecosystem
- Represented the platform in industry-wide forums
- Drove technical adoption and improved system reliability through cross-platform coordination
**Results:**
- Improved system reliability across the AA ecosystem
- Enhanced technical adoption and platform credibility
**Decision authority:** Execution / representation

### OM-CAMS-003: Enterprise FIU Expansion ★
**Situation:** Platform was underutilizing its potential with Financial Information Users (FIUs)
in Lending and WealthTech verticals.
**Task:** Expand platform utility to marquee FIU partners and drive API utilization.
**Actions:**
- Identified new use cases for the AA platform in Lending and WealthTech
- Expanded platform to FIUs: Shubham Housing, Finvasia, Jar, Mahindra Finance,
  INDMoney, Vivriti AIF
- Defined and implemented new API use cases for each partner
**Results:**
- 50% surge in API utilization
- 6 marquee FIUs onboarded and activated
**Decision authority:** Strong influence and execution

### OM-CAMS-004: LAS AA Framework — Credit Decisioning ★ PRIMARY ANCHOR
**Situation:** Loan Against Securities (LAS) entities needed real-time portfolio
monitoring and faster credit decisioning.
**Task:** Engineer an AA framework specifically for LAS credit use cases.
**Actions:**
- Designed AA data framework enabling real-time portfolio monitoring for LAS entities
- Built automated, verified data pipeline for credit decisioning
- Replaced manual document collection with AA-powered verified financial data
**Results:**
- 40% reduction in loan processing time
- Automated, verified data-driven credit decisioning enabled
**Decision authority:** Final call (design and architecture)

### OM-CAMS-005: ReBIT Compliance — 100% Data Accuracy ★
**Situation:** Regulatory and operational risk from non-compliance with ReBIT standards
across the FIP network.
**Task:** Lead ReBIT-standard compliance initiatives to ensure data integrity.
**Actions:**
- Directed ReBIT-standard compliance initiatives across the platform
- Implemented automated checks on data accuracy across FIP network
- Ensured all FIP data met regulatory standards
**Results:**
- 100% data accuracy across the entire FIP network
- Regulatory and operational risk mitigated
**Decision authority:** Final call

### OM-CAMS-006: SQL Analytics Dashboard Suite ★
**Situation:** Client queries were being handled manually, causing delays and inconsistent
resolution quality.
**Task:** Build a scalable analytics layer to resolve client queries efficiently.
**Actions:**
- Built SQL-powered analytics dashboards providing real-time platform insights
- Designed dashboards for recurring query patterns to enable self-service
- Used data insights to proactively resolve issues before client escalation
**Results:**
- 100+ monthly client queries resolved via dashboards
- 95% CSAT (Client Satisfaction) rating
**Decision authority:** Final call

---

## Hackathon Win ★
**Sahamati (RBI) BuildAAthon 2024** — Winner, co-hosted with Devfolio
**Product Built:** Automated Nominee Tracker using the Account Aggregator framework
**Signal:** Shows initiative beyond day job; AA framework applied to a real consumer
problem (nominee management in financial accounts). Strong credibility signal for
AA-adjacent roles.

---

## Key Numbers
- 78% platform efficiency (merchant onboarding)
- 32% drop-off reduction (merchant onboarding)
- 50% API utilization surge (FIU expansion)
- 40% loan processing time reduction (LAS)
- 100% data accuracy (ReBIT compliance)
- 95% CSAT (analytics)
- 100+ monthly client queries resolved

## Tools
SQL, Python, Metabase, Notion, Jira, Confluence

*Version: 1.0 | Updated: May 2026*
