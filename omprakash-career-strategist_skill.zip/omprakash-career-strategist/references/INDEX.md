# Om Prakash B — Master Profile Index
*Version: 1.0 | Updated: May 2026*

---

## Career Timeline

| Period | Company | Role | Stage |
|--------|---------|------|-------|
| 2021 | Saveetha Engineering College | B.E. Electronics & Communication | Foundation |
| 2023 | ISSM Business School | MBA — Operations & Marketing | Education |
| Apr'23–May'24 | CAMS FinServ Account Aggregator | Product Management Trainee | Builder / Ecosystem |
| May'24–Dec'24 | LXME Financial Services | Associate Product Manager | B2C / Consumer |
| Feb'25–Present | M2P Fintech | Associate Product Manager | LOS / Lending Platform |

---

## Identity Snapshot

- **~3 years** in fintech product: Account Aggregator → B2C wealth/investment → Lending (MFI/LOS)
- **Current role:** APM, LOS Platform (MFI Lending), M2P Fintech — Bangalore
- **Education:** B.E. Electronics & Communication (7.4 GPA) | MBA Operations & Marketing (7.8 GPA), ISSM
- **Personal brand:** Sahamati BuildAAthon 2024 Hackathon Winner — Automated Nominee Tracker
- **Inbound demand:** AA ecosystem, lending tech, onboarding optimization, data/analytics

---

## Personal Operating Model

- **Decision process:** Gap analysis → solution documentation → stakeholder validation
- **Under pressure defaults to:** Data (SQL dashboards), documentation (solution docs), user research
- **Core diagnostic metrics:** Conversion rate, drop-off rate, crash rate, API utilization, CSAT
- **Tool fluency:** Figma (design), SQL + Metabase (analytics), Jira (delivery), MoEngage (engagement)
- **Hackathon-proven:** Built Automated Nominee Tracker using AA framework — won Sahamati/RBI BuildAAthon 2024

---

## Decision Authority Map

### Final Call + Execution
M2P: LOS data migration accuracy, individual microloan framework architecture
LXME: Onboarding redesign, crash rate remediation, Lxme Lite conceptualization
CAMS: SQL analytics suite, LAS AA framework design, ReBIT compliance implementation

### Strong Influence + Execution
M2P: Platform V2 GTM, KOTAK BSS MFI pilot, sprint planning and feature delivery
LXME: PPI launch, vendor partnerships, automated reporting infrastructure
CAMS: Merchant onboarding revamp, Sahamati ecosystem engagement, FIU expansion

### Execution / Support
CAMS: Industry forum representation, Sahamati coordination

---

## Cross-Cutting Skills Index

### Lending Tech / LOS
- LOS platform migration (V1→V2) with 100% data accuracy — see `cross-cutting/lending-los.md`
- MFI lending: JLG → individual microloan product architecture
- LAS (Loan Against Securities) AA framework — real-time portfolio monitoring
- 40% loan processing time reduction via automated data-driven credit decisioning

### Onboarding & Conversion
- LXME: 81% → 32% late-stage abandonment (friction analysis + UX redesign)
- CAMS: 32% drop-off reduction, 78% platform efficiency via data-backed journey revamp
- Full-KYC PPI onboarding for 50,000+ active users
- See `cross-cutting/onboarding-conversion.md`

### Account Aggregator / Open Finance
- CAMS FinServ AA platform — ReBIT-standard compliance, FIP network
- Sahamati partnership — represented platform in industry forums
- AA framework for LAS — credit decisioning on verified financial data
- Hackathon Win: Automated Nominee Tracker (Sahamati BuildAAthon 2024)
- See `cross-cutting/aa-open-finance.md`

### Data & Analytics
- SQL-powered dashboards: 100+ monthly client queries resolved, 95% CSAT
- Automated reporting: PPI, daily investments, in-app engagement metrics (LXME)
- Real-time dashboards and alerting for lending operations (M2P)
- Tools: SQL, Python, Metabase, PowerBI, Firebase, Appsflyer, MoEngage

### Platform Delivery & GTM
- 50+ features delivered end-to-end at M2P (sprint planning → test review → release)
- Platform V2 pilot across 10 live KOTAK BSS MFI branches
- 30% time-to-market acceleration via vendor partnerships (LXME)
- 50% API utilization increase via FIU expansion (CAMS)

### Compliance & Regulatory
- ReBIT-standard compliance: 100% data accuracy across FIP network (CAMS)
- AA ecosystem governance: Sahamati Open Finance framework
- MFI lending regulations (RBI): JLG and individual microloan frameworks (M2P)
- PPI full-KYC compliance, MF Central integration (LXME)

---

## Key Numbers to Lead With

- 81% → 32% onboarding abandonment (LXME)
- 7% → 1.72% app crash rate (LXME)
- 40% growth in user base via Lxme Lite
- 100% data accuracy on LOS migration (M2P)
- 50+ features delivered at M2P
- 78% platform efficiency at CAMS
- 32% drop-off reduction at CAMS
- 40% loan processing time reduction (CAMS LAS)
- 50% API utilization surge (CAMS FIU expansion)
- 95% CSAT (CAMS analytics)

---

## Recognition & Awards

- **Winner** — Sahamati (RBI) BuildAAthon 2024 Hackathon, co-hosted with Devfolio
  Product: Automated Nominee Tracker using AA framework

---

## Known Gaps Registry (Summary)

See full details in SKILL.md. Key gaps:
- People management / direct reports (not yet in profile)
- Pricing & monetisation decisions (no evidence)
- Global / Western market product context (India-focused so far)
- Formal enterprise sales cycle (FIU partnerships are adjacent, not identical)
- Growth / PLG strategy ownership at scale

---

*Index Version: 1.0 | Updated: May 2026*
*Cross-reference: 16 STAR nodes across 3 companies*
