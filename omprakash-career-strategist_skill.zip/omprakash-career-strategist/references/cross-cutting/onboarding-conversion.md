# Cross-Cutting: Onboarding & Conversion Optimization
*Version: 1.0 | Updated: May 2026*

---

## Overview
Onboarding conversion is Om's most consistent proof point across all three companies.
Every role contains at least one verified drop-off reduction result.

---

## Proof Points

| Company | What Was Fixed | Result |
|---------|---------------|--------|
| LXME | Late-stage investment onboarding abandonment | 81% → 32% abandonment |
| CAMS | Merchant onboarding journey drop-off | 32% reduction in drop-off |
| CAMS | Merchant onboarding efficiency | 78% platform efficiency |
| M2P | V2 user journey friction (process optimization) | Manual friction reduced |

---

## Methodology Pattern (Consistent Across Roles)
1. Data-first: identify exact drop-off points via analytics (Metabase, Firebase, SQL)
2. User research: validate friction hypothesis
3. UX redesign: work with design tools (Figma) to prototype improvements
4. Engineer collaboration: spec and review implementations
5. Measure: track conversion metrics post-launch

---

## How to Use in Interviews

For **Growth PM / Onboarding PM roles:**
Lead with: LXME-001 (81%→32%), CAMS-001 (32% drop-off reduction)
Through-line: "I've solved the same friction problem in B2C investments and B2B AA onboarding."

For **Consumer / B2C Product roles:**
Lead with: LXME-001, LXME-005 (Lxme Lite), LXME-002 (crash rate)
Through-line: "Shipped fast, measured everything, kept users in the funnel."

For **Platform PM / B2B roles:**
Lead with: CAMS-001, M2P-002, M2P-003
Through-line: "Every transition has a friction problem. I find it in the data and fix it in the process."

---

## Known Limits
- No A/B testing infrastructure ownership at scale (LXME had experimentation but scale unclear)
- Conversion work has been on relatively early-stage products
- No paid acquisition or growth marketing context

*Version: 1.0 | Updated: May 2026*
