# M2P Fintech — Reference File
*Role: Associate Product Manager, LOS Platform (MFI Lending)*
*Period: Feb 2025 – Present*
*Version: 1.0 | Updated: May 2026*

---

## Context
M2P is a B2B fintech infrastructure company. Om joined as APM on the Loan Origination
System (LOS) product team. Primary client: KOTAK BSS MFI (microfinance institution).
Work spans platform migration (V1→V2), product delivery, GTM execution, and lending
product innovation (JLG → individual microloans).

**Framing for interviews:** Use M2P for:
- LOS platform migration and data integrity
- MFI/microfinance lending product depth
- Stakeholder alignment with banking/NBFC clients
- Sprint delivery and feature lifecycle ownership
- Platform thinking: V1 → V2 architecture evolution
- Individual microloan product design

---

## STAR Nodes

### OM-M2P-001: LOS Data Migration V1→V2 ★ PRIMARY ANCHOR
**Situation:** M2P needed to migrate the entire Loan Origination System data from
Platform V1 to the new V2 architecture. Any data loss or corruption would directly
impact loan records and KOTAK BSS MFI operations.
**Task:** Lead the migration with zero data loss or mistreatment.
**Actions:**
- Collaborated closely with engineering to map all data entities from V1 to V2 schema
- Designed validation checkpoints at each migration stage to catch discrepancies early
- Authored solution documents for KOTAK BSS MFI team to align on migration sequencing
- Ran parallel validation against V1 baseline to ensure 100% accuracy post-migration
**Results:**
- 100% data accuracy achieved — zero data loss or mistreatment
- Zero operational disruption to KOTAK BSS MFI during transition
**Decision authority:** Final call and execution

### OM-M2P-002: Platform V2 Gap Analysis & Process Optimization
**Situation:** V2 platform launched but daily operations still carried friction inherited
from V1 workflows. Users experienced unnecessary manual steps.
**Task:** Identify and close the gap between V1 operational reality and V2 design intent.
**Actions:**
- Conducted comprehensive gap analysis comparing V1 daily ops to V2 user journey
- Identified friction points causing manual workarounds
- Optimized platform features to eliminate manual steps and reduce operational friction
**Results:** Streamlined V2 user journey; reduced manual friction for field operations
**Decision authority:** Strong influence and execution

### OM-M2P-003: KOTAK BSS MFI Stakeholder Alignment ★
**Situation:** Introducing V2 with process changes to a live MFI client required careful
alignment to prevent operational disruption during the transition.
**Task:** Align KOTAK BSS MFI team without disrupting daily lending operations.
**Actions:**
- Authored 15+ solution documents covering each process change and its rationale
- Conducted alignment sessions with KOTAK BSS MFI operational teams
- Designed time-saving enhancements specifically mapped to their workflows
- Used documentation to pre-empt confusion and reduce back-and-forth during rollout
**Results:**
- Zero operational disruption during V2 transition
- 15+ solution documents created and adopted
- Client team aligned on all process changes before go-live
**Decision authority:** Strong influence and execution

### OM-M2P-004: Feature Delivery at Scale ★
**Situation:** V2 platform required rapid feature buildout to reach operational parity
with V1 while improving on it.
**Task:** Own the end-to-end feature delivery lifecycle.
**Actions:**
- Managed sprint planning, backlog grooming, and test case reviews
- Directed feature prioritization based on gap analysis insights
- Ensured quality gates before each release
**Results:**
- 50+ platform features delivered end-to-end
- High-quality, on-time releases maintained
**Decision authority:** Strong influence and execution

### OM-M2P-005: GTM — Platform V2 Pilot Launch
**Situation:** V2 needed real-world validation before full rollout.
**Task:** Execute a controlled pilot launch across KOTAK BSS MFI branches.
**Actions:**
- Managed launch of V2 across 10 KOTAK BSS MFI pilot branches
- Validated core system stability and operational workflows in live environment
- Captured and triaged field feedback for rapid iteration
**Results:**
- Successful validation of system stability across 10 live branches
- Core operational workflows confirmed in production environment
**Decision authority:** Strong influence and execution

### OM-M2P-006: Individual Microloan Framework ★
**Situation:** M2P's lending portfolio was limited to traditional JLG (Joint Liability
Group) models — group-based lending with limited flexibility for individual borrowers.
**Task:** Architect an individual microloan framework to expand the product offering.
**Actions:**
- Designed product framework for individual microloans beyond JLG group model
- Architected credit product specifications for more flexible, personalized lending
- Worked with engineering to define the loan lifecycle for individual vs. group models
**Results:**
- Successfully transitioned lending portfolio to support individual microloans
- Delivered more flexible and personalized credit products to MFI clients
**Decision authority:** Final call

---

## Key Numbers
- 100% data accuracy on LOS migration
- 50+ features delivered end-to-end
- 10 pilot branches successfully launched on V2
- 15+ solution documents authored for KOTAK BSS MFI

## Tools
Jira, Confluence, DevRev, Notion, Figma, Boardmix, SQL

*Version: 1.0 | Updated: May 2026*
