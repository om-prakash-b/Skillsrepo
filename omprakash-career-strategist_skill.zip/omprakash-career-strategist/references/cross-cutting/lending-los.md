# Cross-Cutting: Lending Tech & LOS
*Version: 1.0 | Updated: May 2026*

---

## Overview
Om's lending depth spans three distinct credit contexts:
1. **Microfinance (MFI):** JLG and individual microloan product design at M2P
2. **Loan Against Securities (LAS):** AA-powered credit decisioning at CAMS
3. **LOS Platform Engineering:** Migration, data integrity, and feature delivery at M2P

---

## Proof Points by Lending Dimension

### LOS / Platform Engineering
- Led V1→V2 LOS migration with 100% data accuracy, zero data loss (M2P)
- Delivered 50+ platform features across MFI loan lifecycle (M2P)
- Piloted V2 in 10 live KOTAK BSS MFI branches (M2P)
- **Key signal:** Rare for an APM to own data migration end-to-end. Shows technical
  credibility and risk ownership.

### MFI / Microfinance Lending
- Product owner for KOTAK BSS MFI client on M2P platform
- Architected individual microloan framework beyond traditional JLG group model
- 15+ solution documents for operational alignment during platform transitions
- **Key signal:** MFI context (RBI-regulated) shows comfort with lending compliance

### AA-Powered Credit / LAS
- Designed AA framework for LAS entities — real-time portfolio monitoring
- 40% reduction in loan processing time via automated credit decisioning
- 100% data accuracy across FIP network (ReBIT compliance)
- **Key signal:** Positions Om at intersection of Open Finance + lending — a rare combination

---

## How to Use in Interviews

For **Lending / Credit PM roles:**
Lead with: M2P-001 (migration), M2P-006 (microloan framework), CAMS-004 (LAS)
Through-line: "From data infrastructure to product design — across MFI, LAS, and platform."

For **LOS / Core Lending Platform roles:**
Lead with: M2P-001, M2P-004, M2P-005
Through-line: "Owned data integrity, feature delivery, and live GTM on a lending platform."

For **Fintech Credit Infrastructure roles:**
Lead with: CAMS-004, M2P-001, CAMS-005
Through-line: "Built credit data infrastructure (AA) and lending platform (LOS) from both sides."

---

## Known Limits
- No personal credit / underwriting model design (risk scoring, bureau integration)
- No consumer lending (home loans, personal loans, auto loans) context
- No NBFC-level P&L or portfolio risk ownership
- LAS context is framework design, not production-scale servicing

*Version: 1.0 | Updated: May 2026*
