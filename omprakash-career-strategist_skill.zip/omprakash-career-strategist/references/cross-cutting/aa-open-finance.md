# Cross-Cutting: Account Aggregator & Open Finance
*Version: 1.0 | Updated: May 2026*

---

## Overview
Om has the deepest AA ecosystem experience available at his career stage.
Built on a year at CAMS FinServ (one of India's leading AA platforms) + Sahamati hackathon win.
This is a genuine differentiator — very few PMs have both platform-side and ecosystem-level AA exposure.

---

## Proof Points

### Platform-Side (CAMS FinServ AA)
- ReBIT-standard compliance: 100% data accuracy across entire FIP network
- LAS AA framework: real-time portfolio monitoring, 40% loan processing time reduction
- Merchant onboarding: 78% efficiency, 32% drop-off reduction
- Enterprise FIU expansion: 50% API utilization surge, 6 marquee FIU partners
- SQL analytics: 95% CSAT, 100+ monthly queries resolved

### Ecosystem-Side (Sahamati Partnership)
- Represented CAMS at Sahamati (RBI-backed Open Finance governing body) forums
- Influenced AA ecosystem standards through industry participation
- Improved system reliability via cross-platform coordination

### Hackathon (Independent Initiative)
- **Winner:** Sahamati BuildAAthon 2024, co-hosted with Devfolio
- **Built:** Automated Nominee Tracker using AA framework
- **Signal:** Applied AA framework to solve a real consumer pain (nominee management)
  independently — shows product thinking beyond job scope

---

## AA Ecosystem Knowledge
- ReBIT standards and FIP/FIU architecture
- Consent management and data flow in AA framework
- AA for credit use cases (LAS, lending)
- AA for wealth management use cases (MF Central integration at LXME)
- Sahamati governance and ecosystem dynamics

---

## How to Use in Interviews

For **AA / Open Finance PM roles:**
Lead with: CAMS-004 (LAS), CAMS-005 (ReBIT), CAMS-003 (FIU expansion), hackathon win
Through-line: "I've been inside the AA platform and in the ecosystem. I know both sides."

For **Fintech infrastructure roles:**
Lead with: CAMS-005, CAMS-004, CAMS-002
Through-line: "Compliance, data infra, and ecosystem partnerships — built in production."

For **Credit / Lending roles with data angle:**
Lead with: CAMS-004 (AA-powered LAS), CAMS-005 (ReBIT compliance)
Through-line: "AA for credit is not theoretical — I designed and shipped the LAS framework."

---

## Known Limits
- No cross-border AA or international Open Banking (UK Open Banking, PSD2) context
- No FIU-side product experience (always been AA platform / consent manager side)
- Hackathon product is an MVP, not production infrastructure

*Version: 1.0 | Updated: May 2026*
